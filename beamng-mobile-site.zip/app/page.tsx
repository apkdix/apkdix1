"use client"

import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Facebook, Twitter, Instagram, Youtube } from "lucide-react"

const InstallationGuide = () => {
  return (
    <div>
      <p className="mb-2">1. قم بتنزيل ملف APK من الرابط أعلاه.</p>
      <p className="mb-2">2. قم بتثبيت ملف APK على جهاز الأندرويد الخاص بك.</p>
      <p className="mb-2">3. قم بتشغيل اللعبة واستمتع!</p>
    </div>
  )
}

export default function Home() {
  return (
    <div className="min-h-screen bg-[#121212] text-[#e0e0e0]">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-[#1e1e1e] shadow-md">
        <nav className="max-w-7xl mx-auto flex justify-between items-center px-5 py-3">
          <Link
            href="https://www.modxnet.com"
            className="flex items-center gap-2 px-3 py-2 rounded-full bg-white/10 text-[#e0e0e0] hover:bg-white/20 hover:text-[#00ffcc] transition-colors"
          >
            <ArrowLeft size={16} />
            <span className="font-medium">العودة للرئيسية</span>
          </Link>

          <div className="md:hidden">
            <button id="menuButton" className="text-white text-2xl">
              <span className="sr-only">القائمة</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <line x1="4" x2="20" y1="12" y2="12" />
                <line x1="4" x2="20" y1="6" y2="6" />
                <line x1="4" x2="20" y1="18" y2="18" />
              </svg>
            </button>
          </div>

          <ul className="hidden md:flex gap-5 items-center">
            <li>
              <Link href="#" className="text-[#e0e0e0] hover:text-[#00ffcc] font-medium transition-colors">
                الرئيسية
              </Link>
            </li>
            <li>
              <Link href="#" className="text-[#e0e0e0] hover:text-[#00ffcc] font-medium transition-colors">
                التطبيقات الشائعة
              </Link>
            </li>
            <li>
              <Link href="#" className="text-[#e0e0e0] hover:text-[#00ffcc] font-medium transition-colors">
                الإصدارات الجديدة
              </Link>
            </li>
            <li>
              <Link href="#" className="text-[#e0e0e0] hover:text-[#00ffcc] font-medium transition-colors">
                الفئات
              </Link>
            </li>
          </ul>
        </nav>
      </header>

      {/* Hero Section */}
      <div className="relative h-[250px] overflow-hidden">
        <Image
          src="/placeholder.svg?height=250&width=1200"
          alt="BeamNG.drive Mobile Cover"
          fill
          className="object-cover"
          priority
        />
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-5 py-5">
        {/* Game Info */}
        <div className="flex flex-col md:flex-row items-center gap-5 mb-6 md:text-left text-center">
          <div className="w-[100px] h-[100px] rounded-[20px] border-[3px] border-[#00ffcc] overflow-hidden relative">
            <Image
              src="/placeholder.svg?height=100&width=100"
              alt="BeamNG.drive Mobile Logo"
              fill
              className="object-cover"
            />
          </div>
          <div>
            <h1 className="text-2xl font-semibold mb-2">BeamNG.drive Mobile</h1>
            <small className="text-white/70">للأندرويد و iOS</small>
          </div>
        </div>

        {/* Download Buttons */}
        <div className="text-center my-6">
          <button
            className="inline-flex items-center gap-2 px-8 py-3 bg-[#00ffcc] text-[#121212] rounded-full font-bold hover:bg-[#00ccff] transition-colors m-2 w-full md:w-auto justify-center"
            onClick={() => alert("تم النقر على زر التحميل للأندرويد")}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M5 12V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v7" />
              <path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7" />
              <path d="M5 12h14" />
            </svg>
            تحميل للأندرويد
          </button>
          <button
            className="inline-flex items-center gap-2 px-8 py-3 bg-[#00ffcc] text-[#121212] rounded-full font-bold hover:bg-[#00ccff] transition-colors m-2 w-full md:w-auto justify-center"
            onClick={() => alert("تم النقر على زر التحميل للـ iOS")}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M12 20.94c1.5 0 2.75 1.06 4 1.06 3 0 6-8 6-12.22A4.91 4.91 0 0 0 17 5c-2.22 0-4 1.44-5 2-1-.56-2.78-2-5-2a4.9 4.9 0 0 0-5 4.78C2 14 5 22 8 22c1.25 0 2.5-1.06 4-1.06Z" />
              <path d="M10 2c1 .5 2 2 2 5" />
            </svg>
            تحميل للـ iOS
          </button>
        </div>

        {/* Specs Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-[#1e1e1e] p-4 rounded-lg text-center">
            <h3 className="text-[#00ffcc] mb-2 text-base font-medium">الحجم</h3>
            <p className="text-sm">983.41MB (المثبت) 8GB (ملفات الكاش)</p>
          </div>
          <div className="bg-[#1e1e1e] p-4 rounded-lg text-center">
            <h3 className="text-[#00ffcc] mb-2 text-base font-medium">السعر</h3>
            <p className="text-sm">مجاني</p>
          </div>
          <div className="bg-[#1e1e1e] p-4 rounded-lg text-center">
            <h3 className="text-[#00ffcc] mb-2 text-base font-medium">متوافق مع الأندرويد</h3>
            <p className="text-sm">كوالكوم سنابدراجون 845 وأفضل، 4GB رام</p>
          </div>
          <div className="bg-[#1e1e1e] p-4 rounded-lg text-center">
            <h3 className="text-[#00ffcc] mb-2 text-base font-medium">أجهزة iOS المطلوبة</h3>
            <p className="text-sm">آيفون XS Max أو أحدث، آيباد برو 2018 أو أحدث</p>
          </div>
        </div>

        {/* Installation Guide */}
        <div className="bg-[#1e1e1e] p-5 rounded-lg mb-8">
          <h2 className="text-2xl text-[#00ffcc] mb-4">دليل التثبيت</h2>

          <InstallationGuide />
        </div>

        {/* Features */}
        <div className="mb-8">
          <h2 className="text-2xl text-[#00ffcc] mb-4">المميزات</h2>
          <ul className="space-y-2">
            {[
              "فيزياء متقدمة: محرك فيزياء واقعي للتصادمات الأصيلة",
              "تنوع المركبات: أكثر من 20 مركبة مفصلة مع تحكم واقعي",
              "عالم مفتوح: خرائط ضخمة مع تضاريس ديناميكية وعوائق",
              "نظام الأضرار: تشوه في الوقت الحقيقي وأضرار للأجزاء",
              "سيناريوهات مخصصة: إنشاء ومشاركة تحديات القيادة الخاصة بك",
            ].map((feature, index) => (
              <li
                key={index}
                className="relative pl-5 before:content-['•'] before:absolute before:left-0 before:text-[#00ffcc] before:text-xl"
              >
                {feature}
              </li>
            ))}
          </ul>
        </div>

        {/* Screenshots */}
        <div className="mb-8">
          <h2 className="text-2xl text-[#00ffcc] mb-4">لقطات الشاشة</h2>
          <div className="flex gap-4 overflow-x-auto pb-4 snap-x">
            {[1, 2, 3].map((num) => (
              <div key={num} className="flex-none w-[250px] h-[150px] relative rounded-lg overflow-hidden snap-start">
                <Image
                  src={`/placeholder.svg?height=150&width=250&text=Screenshot ${num}`}
                  alt={`BeamNG.drive Mobile Screenshot ${num}`}
                  fill
                  className="object-cover"
                />
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-[#1e1e1e] text-[#e0e0e0] py-8 px-5">
        <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-[#00ffcc] text-base mb-4">من نحن</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="hover:text-[#00ffcc] transition-colors">
                  مهمتنا
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#00ffcc] transition-colors">
                  الفريق
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#00ffcc] transition-colors">
                  وظائف
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#00ffcc] transition-colors">
                  اتصل بنا
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-[#00ffcc] text-base mb-4">روابط سريعة</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="hover:text-[#00ffcc] transition-colors">
                  الرئيسية
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#00ffcc] transition-colors">
                  التطبيقات الشائعة
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#00ffcc] transition-colors">
                  الإصدارات الجديدة
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#00ffcc] transition-colors">
                  الفئات
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-[#00ffcc] text-base mb-4">قانوني</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="hover:text-[#00ffcc] transition-colors">
                  سياسة الخصوصية
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#00ffcc] transition-colors">
                  شروط الخدمة
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#00ffcc] transition-colors">
                  إخلاء المسؤولية
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-[#00ffcc] text-base mb-4">تابعنا</h3>
            <div className="flex gap-4">
              <Link href="#" aria-label="Facebook" className="text-[#e0e0e0] hover:text-[#00ffcc] transition-colors">
                <Facebook size={20} />
              </Link>
              <Link href="#" aria-label="Twitter" className="text-[#e0e0e0] hover:text-[#00ffcc] transition-colors">
                <Twitter size={20} />
              </Link>
              <Link href="#" aria-label="Instagram" className="text-[#e0e0e0] hover:text-[#00ffcc] transition-colors">
                <Instagram size={20} />
              </Link>
              <Link href="#" aria-label="YouTube" className="text-[#e0e0e0] hover:text-[#00ffcc] transition-colors">
                <Youtube size={20} />
              </Link>
            </div>
          </div>
        </div>
        <div className="text-center mt-8 pt-4 border-t border-white/10">
          &copy; 2025{" "}
          <Link href="#" className="hover:text-[#00ffcc]">
            Modlify.fun
          </Link>
          . جميع الحقوق محفوظة. | تم التصميم بواسطة{" "}
          <Link href="https://www.youtube.com/@Modlify-Games" target="_blank" className="hover:text-[#00ffcc]">
            Modlify Games
          </Link>
        </div>
      </footer>
    </div>
  )
}
