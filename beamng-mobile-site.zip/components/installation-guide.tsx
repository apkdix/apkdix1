"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

export default function InstallationGuide() {
  const [activeTab, setActiveTab] = useState<"android" | "ios">("android")

  return (
    <div>
      <div className="flex flex-col md:flex-row gap-2 mb-5">
        <button
          onClick={() => setActiveTab("android")}
          className={cn(
            "px-4 py-2 rounded-full text-sm border border-white/10 transition-colors",
            activeTab === "android" ? "bg-[#00ffcc] text-[#121212] border-transparent" : "bg-[#121212]",
          )}
        >
          أندرويد
        </button>
        <button
          onClick={() => setActiveTab("ios")}
          className={cn(
            "px-4 py-2 rounded-full text-sm border border-white/10 transition-colors",
            activeTab === "ios" ? "bg-[#00ffcc] text-[#121212] border-transparent" : "bg-[#121212]",
          )}
        >
          iOS
        </button>
      </div>

      <div className="bg-[#121212] p-4 rounded-lg">
        {activeTab === "android" ? (
          <ul className="space-y-3">
            {[
              "قم بتنزيل ملف APK باستخدام زر تنزيل Android أعلاه",
              'انتقل إلى الإعدادات > الأمان > تمكين "المصادر غير المعروفة"',
              "حدد موقع ملف APK الذي تم تنزيله في مدير الملفات الخاص بك",
              "اضغط للتثبيت واتبع التعليمات التي تظهر على الشاشة",
              "بعد التثبيت، قم بتنزيل ملفات ذاكرة التخزين المؤقت الإضافية",
              "ضع ملفات ذاكرة التخزين المؤقت في مجلد Android/obb/",
              "قم بتشغيل اللعبة واستمتع!",
            ].map((step, index) => (
              <li
                key={index}
                className="relative pr-6 before:content-['→'] before:absolute before:right-0 before:text-[#00ffcc]"
              >
                {step}
              </li>
            ))}
          </ul>
        ) : (
          <ul className="space-y-3">
            {[
              "قم بتنزيل ملف IPA باستخدام زر تنزيل iOS",
              "قم بتثبيت AltStore على جهاز الكمبيوتر الخاص بك (مطلوب Windows / Mac)",
              "قم بتوصيل جهاز iOS الخاص بك وافتح AltStore",
              'حدد "تثبيت .ipa" واختر الملف الذي تم تنزيله',
              "أدخل معرف Apple الخاص بك عند مطالبتك",
              "ثق بالمطور في الإعدادات > عام > إدارة الجهاز",
              "قم بتشغيل اللعبة وتنزيل الموارد الإضافية",
            ].map((step, index) => (
              <li
                key={index}
                className="relative pr-6 before:content-['→'] before:absolute before:right-0 before:text-[#00ffcc]"
              >
                {step}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}
