"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu } from "lucide-react"

export default function MobileMenu() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="md:hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="text-white text-2xl"
        aria-label={isOpen ? "إغلاق القائمة" : "فتح القائمة"}
      >
        <Menu />
      </button>

      {isOpen && (
        <ul className="absolute top-[70px] right-5 bg-[#1e1e1e] p-4 rounded-lg shadow-lg flex flex-col gap-3 z-50">
          <li>
            <Link href="#" className="text-[#e0e0e0] hover:text-[#00ffcc] font-medium transition-colors">
              الرئيسية
            </Link>
          </li>
          <li>
            <Link href="#" className="text-[#e0e0e0] hover:text-[#00ffcc] font-medium transition-colors">
              التطبيقات الشائعة
            </Link>
          </li>
          <li>
            <Link href="#" className="text-[#e0e0e0] hover:text-[#00ffcc] font-medium transition-colors">
              الإصدارات الجديدة
            </Link>
          </li>
          <li>
            <Link href="#" className="text-[#e0e0e0] hover:text-[#00ffcc] font-medium transition-colors">
              الفئات
            </Link>
          </li>
        </ul>
      )}
    </div>
  )
}
